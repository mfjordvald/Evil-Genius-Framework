<?php
$cache_namespace   = 'fw53';
$cache_server_ip   = '127.0.0.1';
$cache_server_port = 11211;

$db_host           = 'localhost';
$db_database       = 'cachetest';
$db_username       = 'username';
$db_password       = 'password';
$db_debug          = true;